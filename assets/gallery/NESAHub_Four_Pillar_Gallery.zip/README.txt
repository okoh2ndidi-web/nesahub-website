NESAHub four-pillar gallery (preview package)

Open index.html in a browser to preview.

To integrate: copy the section with class nesahub-pillars into the website homepage, add gallery.css rules to existing stylesheet (or link the file), and place the four JPG files in assets/. Existing pillar page links are workmen.html, materials.html, housing.html, property-management.html.

Images use the user-provided Workmen and Materials pictures, and crops of the Housing and Property Management photographs from the supplied screenshot. This package is not deployed.
